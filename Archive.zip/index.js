//const express = require("express");
import express from "express";
import path, { resolve } from "path";


const app = express();
const PORT = 3000;

app.use(express.static("public"));

app.get("/",(req, res) => {
    res.sendFile(path.resolve("public/index.html"));
});


app.listen(PORT, () => {
    console.log("your server is running")
});
